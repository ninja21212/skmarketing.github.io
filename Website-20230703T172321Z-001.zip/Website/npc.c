#include <stdio.h>
#include <conio.h>
int main()
{
printf ( "I am in main function\n" ) ;
void UVPCE()
{
printf ( "I am CEIT student\n" ) ;
}
return 0;
}